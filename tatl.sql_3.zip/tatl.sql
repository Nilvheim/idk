-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Agu 2023 pada 05.11
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tatl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dospem`
--

CREATE TABLE `dospem` (
  `nama` varchar(50) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `bidang` varchar(50) NOT NULL,
  `prodi` varchar(50) NOT NULL,
  `jurusan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `dospem`
--

INSERT INTO `dospem` (`nama`, `nip`, `bidang`, `prodi`, `jurusan`) VALUES
('Mikail Eko Prasetyo Widagda, S.T., M.T.', ' 197807012021211008', 'Teknik Elektronika Industri', 'Teknologi Listrik', 'Rekayasa elektro'),
('Hilmansyah, S.T., M.T.', '197608202010011013', 'Teknologi Listrik', 'Teknologi Listrik', 'Rekayasa Elektro'),
('Andi Sri Irtawaty, S.T., M.Eng.', '197704012021212005', 'Teknik Telekomunikasi', 'Teknologi listrik', 'Rekayasa Elektro'),
('Hadiyanto, S.T., M.Eng', '198007082014041001', 'Teknologi Listrik', 'Teknologi listrik', 'Rekayasa Elektro'),
('Dwi Lesmideyarti, S.T., M.Kom.', '198605032019032011', 'Teknik Informatika', 'Teknologi Listrik', 'Rekayasa Elektro'),
('Zulkarnain, S.Pd, M.Pd', '199301042020121005', 'MKDU', 'Teknologi Listrik', 'Rekayasa Elektro'),
('Angga Wahyu Aditya, S.S.T., M.T. ', '199411012019031015', 'Teknologi Listrik', 'Teknologi Listrik', 'Rekayasa Elektro');

-- --------------------------------------------------------

--
-- Struktur dari tabel `dwi`
--

CREATE TABLE `dwi` (
  `nama` varchar(50) NOT NULL,
  `nim` int(15) NOT NULL,
  `topik_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `hadiyanto`
--

CREATE TABLE `hadiyanto` (
  `nama` varchar(50) NOT NULL,
  `nim` int(15) NOT NULL,
  `topik_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `hadiyanto`
--

INSERT INTO `hadiyanto` (`nama`, `nim`, `topik_ta`) VALUES
('akwokaodk', 912838123, 'sajsojdoas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `hilmansyah`
--

CREATE TABLE `hilmansyah` (
  `nama` varchar(50) NOT NULL,
  `nim` int(15) NOT NULL,
  `topik_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `irtawaty`
--

CREATE TABLE `irtawaty` (
  `nama` varchar(50) NOT NULL,
  `nim` int(20) NOT NULL,
  `topik_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `logins`
--

CREATE TABLE `logins` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `logins`
--

INSERT INTO `logins` (`username`, `password`) VALUES
('Raja', '982021001'),
('Rudiansyah', '982021003'),
('Nurhaliza', '982021004'),
('Hendra', '982021007'),
('Handika', '982021008'),
('Rizal', '982021009'),
('Afdillah', '982021010'),
('Anshori', '982021011'),
('Ega', '982021012'),
('Tirta', '982021013'),
('Audi', '982021014'),
('Abdul', '982021015'),
('Iqmal', '982021026'),
('Rifaldy', '982021028'),
('Hariasa', '982021030'),
('Faiiz', '982021031'),
('Neo', '982021032'),
('Iqbal', '982021033'),
('Naufal', '982021034'),
('Zaki', '982021035'),
('Natalino', '982021036'),
('Bima', '982021037'),
('Fahmi', '982021038'),
('Rafif', '982021039'),
('Satriya', '982021040');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login_admin`
--

CREATE TABLE `login_admin` (
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `login_admin`
--

INSERT INTO `login_admin` (`username`, `password`) VALUES
('Admin', '43215678');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login_dosen`
--

CREATE TABLE `login_dosen` (
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `NIP` varchar(50) NOT NULL,
  `id` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `login_dosen`
--

INSERT INTO `login_dosen` (`username`, `password`, `NIP`, `id`) VALUES
('dwi', 'Dwi123', '198605032019032011', 1),
('hadiyanto', 'Hadi123', '', 2),
('hilmansyah', 'Hilman123', '', 3),
('irtawaty', 'irta123', '', 4),
('mikail', 'Mika123', '', 5),
('wahyu', 'Wahyu123', '', 6),
('zulkarnain', 'Zul123', '', 7);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa_ta`
--

CREATE TABLE `mahasiswa_ta` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(100) NOT NULL,
  `dosen` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mahasiswa_ta`
--

INSERT INTO `mahasiswa_ta` (`nama`, `nim`, `topik_ta`, `dosen`) VALUES
('akwokaodk', 912838123, 'sajsojdoas', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mikail`
--

CREATE TABLE `mikail` (
  `nama` varchar(50) NOT NULL,
  `nim` int(15) NOT NULL,
  `topik_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan`
--

CREATE TABLE `permohonan` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` int(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan_dwi`
--

CREATE TABLE `permohonan_dwi` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` int(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan_hadiyanto`
--

CREATE TABLE `permohonan_hadiyanto` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` varchar(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `permohonan_hadiyanto`
--

INSERT INTO `permohonan_hadiyanto` (`nama`, `nim`, `topik_ta`, `dosen`, `nip`, `bidang_keahlian`) VALUES
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda'),
('akwokaodk', 912838123, 'sajsojdoas', 'hadiyanto', '2312312', 'asdasdwda');

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan_hilmansyah`
--

CREATE TABLE `permohonan_hilmansyah` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` int(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan_irtawaty`
--

CREATE TABLE `permohonan_irtawaty` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` int(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan_mikail`
--

CREATE TABLE `permohonan_mikail` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` int(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan_wahyu`
--

CREATE TABLE `permohonan_wahyu` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` int(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permohonan_zulkarnain`
--

CREATE TABLE `permohonan_zulkarnain` (
  `nama` varchar(50) NOT NULL,
  `nim` int(10) NOT NULL,
  `topik_ta` varchar(200) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `nip` int(30) NOT NULL,
  `bidang_keahlian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `wahyu`
--

CREATE TABLE `wahyu` (
  `nama` varchar(50) NOT NULL,
  `nim` int(15) NOT NULL,
  `topik_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `zulkarnain`
--

CREATE TABLE `zulkarnain` (
  `nama` varchar(50) NOT NULL,
  `nim` int(15) NOT NULL,
  `topik_ta` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `dospem`
--
ALTER TABLE `dospem`
  ADD PRIMARY KEY (`nip`);

--
-- Indeks untuk tabel `dwi`
--
ALTER TABLE `dwi`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `hadiyanto`
--
ALTER TABLE `hadiyanto`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `hilmansyah`
--
ALTER TABLE `hilmansyah`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `irtawaty`
--
ALTER TABLE `irtawaty`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `logins`
--
ALTER TABLE `logins`
  ADD PRIMARY KEY (`password`);

--
-- Indeks untuk tabel `login_admin`
--
ALTER TABLE `login_admin`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `login_dosen`
--
ALTER TABLE `login_dosen`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mahasiswa_ta`
--
ALTER TABLE `mahasiswa_ta`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `mikail`
--
ALTER TABLE `mikail`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `wahyu`
--
ALTER TABLE `wahyu`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `zulkarnain`
--
ALTER TABLE `zulkarnain`
  ADD PRIMARY KEY (`nim`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `login_dosen`
--
ALTER TABLE `login_dosen`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
